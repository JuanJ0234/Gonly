<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
label {
  position: relative;
  width: 480px;
  height: 180px;
  display: block;
  background: url('../resource/Gonly.png');
  background-size: cover;
  background-position: center;
  border: 10px solid rgba(198, 247, 253, 0.3);
  border-radius: 100px;
  cursor: pointer;
  transition: 1s ease;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.2);
}
label::after {
  content: '';
  position: absolute;
  height: 110px;
  width: 110px;
  background: #f2f2f2;
  border-radius: 50%;
  top: 25px;
  left: 30px;
  transition: 0.8s ease;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
label::before {
  content: '';
  position: absolute;
  height: 110px;
  width: 110px;
  border: 10px solid rgba(198, 247, 253, 0.3);
  border-radius: 50%;
  top: 15px;
  left: 20px;
  transition: 0.8s ease;
  box-shadow: 0 0 50px rgba(0, 0, 0, 0.18);
}
.background {
  position: absolute;
  width: 100%;
  height: 100vh;
  background: #9ad6f7;
  z-index: -1;
  transition: all 1s ease;
}

input:checked ~ label::after {
  left: 430px;
  transform: translateX(-100%);
  background: #777ba5;
}
input:checked ~ label::before {
  left: 440px;
  border: 10px solid rgba(90, 79, 136, 0.2);
  transform: translateX(-100%);
}
input:checked ~ label {
  background: url('../resource/logo.png');
  background-size: cover;
  background-position: center;
  border: 10px solid rgba(90, 79, 136, 0.2);
}
input:checked ~ .background {
  background: #0e377c;
}
input {
  display: none;
}

</style>


<body>
    <body>
  <input type="checkbox" id="dark-mode">
  <label for="dark-mode"></label>
  <div class="background"></div>
</body>
</body>
</html>