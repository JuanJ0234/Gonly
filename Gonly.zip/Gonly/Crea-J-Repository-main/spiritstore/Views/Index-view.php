<?php session_start();
    if (isset($_SESSION['usuario'])) {
        $link = "../controllers/usuario-valid-control.php";
        $userIndex = $_SESSION['UserSesion-User'];
    } else{
        $link = "../controllers/form-registro-control.php";
        $userIndex = "Registrate";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" href="../resource/Gonly-bolsa.png">
    <link rel="stylesheet" href="../css/styleIndex1.css">
    <link rel="stylesheet" href="../css/styleTraductor1.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gonly</title>
</head>
<body>
    <section>
        <header class="navigator ">
              <a href="index-view.php"><img src="../resource/Gonly.png" alt="Logo" id="Logo"></a>
            <nav id="nav-menu">
              <ul class="Links ul-icons-footer">
                  <li><a href="../errors/404.php"><div class="underLine" id="Lista-div"><img src="../resource/icons/bolsa-white.png" alt="" class="icons-nav Lista-nav"></a></div> </li>
                  <li><a href="../errors/404.php"><div class="underLine" id="carrito-div"><img src="../resource/icons/cart-solid-white.png" alt="" class="icons-nav carrito-nav"></a></div> </li>
                  <li><a href="AllCategories-view.php" ><div class="underLine" id="the-menu-div"><img src="../resource/icons/menu-alt-left-regular-white.png" alt="" class="icons-nav menu-nav"> Categorias</a></div></li>
                  <li><a href="../controllers/form-cotizacion-control.php" ><div class="underLine" id="dolar-div"><img src="../resource/icons/dollar-circle-solid-white.png" alt="" class="icons-nav dollar-nav"> Cotizacion</a></div></li>
              </ul>
            </nav>
            <a href="<?php echo $link?>" class="boton"><div class="aboton"><button><img src="../resource/icons/user-solid-24.png" alt="" class="icons-nav"> <?php echo $userIndex ?> </button></div></a>
            <div class="menu-toggle">
                <i class="fa fa-bars"></i>
            </div>
        </header>
    </section>

    <section>
        <div class="container-slider">
            <div class="slider" id="slider">
                <div class="slider__section">
                    <img src="../resource/slider/slider-img1.png" alt="Carrito" class="slider__img">
                </div>
                <div class="slider__section">
                    <img src="../resource/slider/slider-img2.png" alt="Carro lujoso" class="slider__img">
                </div>
                <div class="slider__section">
                    <img src="../resource/slider/slider-img3.png" alt="Carro lujoso" class="slider__img">
                </div>
                <div class="slider__section">
                    <img src="../resource/slider/slider-img4.png" alt="Carro lujoso" class="slider__img">
                </div>
            </div>
            <div class="slider__btn slider__btn--right" id="btn-right">&#62;</div>
            <div class="slider__btn slider__btn--left"  id="btn-left">&#60;</div>
        </div>
    </section>

    <section>
        <div class="Categories-title cat-linedeco">
            <h1 id="h1-midinfo">Marcas confiables</h1>
        </div>
        <div class="mid-info">
            <div class="information-block information-block-left">
                <h1>Marca</h1>
                <p>
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui adipisci, tempora eos dolor labore temporibus asperiores, eius accusantium voluptatum, cum maiores inventore repellat vitae ullam quas? Ea ipsum animi nisi!
                </p>
                
            </div>
            <div class="information-block">
                <h1>Marca</h1>
                <p>
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore nesciunt dolorem voluptatem sapiente qui modi quas deleniti, voluptatum sed est repellendus, saepe rerum repellat dignissimos perferendis, corrupti eum voluptatibus quasi.
                
            </div>
            <div class="information-block information-block-right">
                <h1>Marca</h1>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Optio ipsum sint, similique soluta nisi necessitatibus commodi alias iusto totam ea rerum, doloremque fugiat cum? Eveniet nisi non quod suscipit id.
                </p>
                
            </div>
        </div>
        <div class="mid-info mid-info-low">
            <div class="information-block information-block-left">
                <h1>Marca</h1>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis accusantium, incidunt quod, tempora animi voluptas maxime modi odit soluta excepturi necessitatibus impedit dolorum exercitationem quas perspiciatis vitae. Nesciunt, impedit doloribus?
                </p>
                
            </div>
            <div class="information-block">
                <h1>Marca</h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, commodi tempore perspiciatis laudantium ipsa soluta nostrum similique incidunt voluptate esse facere est accusantium enim autem. Voluptatum repudiandae eaque nisi autem.
                </p>
                
            </div>
            <div class="information-block information-block-right">
                <h1>Marca</h1>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab laudantium porro ex, iusto voluptate maiores sit, necessitatibus ipsum dolores veniam ratione quos hic harum cumque eos ducimus repellat nihil atque.
                </p>
                
            </div>
        </div>
    </section>

    <section>
        <div class="Categories-title">
            <div class="line-deco">
                <h1 id="categorias"><a href="#categorias">Categorias</a></h1>
            </div>
        </div>
        <div class="Categories-content">
            <div class="allcat">
                <div class="first-categori">
                    <div class="Image-left all-images-cat">
                        <div class="contenido-index">
                            <img src="" alt="">
                        </div>
                        <a href="../views/categoria-1/category-1-view.php">
                            <div class="Image-left-overlay Image-left-overlay-blur">
                                <p class="Image-left-description">
                                Jueguetes
                                </p>
                            </div>
                        </a>
                    </div>
                    <div class="content-text category-1 content-right">
                        <h1>Jueguetes</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit eligendi commodi et laborum neque est illum velit dolores officiis odit voluptatem eum dolorum sapiente rem a, totam fuga. At, id!</p>
                    </div>
                </div>

                <div class="first-categori second-categori">
                    <div class="content-text category-2 content-left">
                        <h1>Carros</h1>
                        <p>Vehículo que circula fuera de las carreteras. Por ende, puede moverse por terrenos con características muy variadas, en cuanto a perfil y adherencia, y cruzar tramos de agua.</p>
                    </div>
                    <div class="Image-left image-right all-images-cat">
                        <img src="../resource/categories/categorias-imagenes/deportivo-image.jpg" alt="">
                        <a href="../views/categoria-2/category-2-view.php">
                            <div class="Image-left-overlay Image-left-overlay-blur">
                                <p class="Image-left-description">
                                Carros
                                </p>
                            </div>
                        </a>
                    </div>
                </div>


                <div class="first-categori second-categori">
                    <div class="Image-left image-right-2 all-images-cat" >
                        <img src="" alt="">
                        <a href="../views/categoria-3/category-3-view.php">
                            <div class="Image-left-overlay Image-left-overlay-blur">
                                <p class="Image-left-description">
                                Tecnologia
                                </p>
                            </div>
                        </a>
                    </div>
                    <div class="content-text category-2 content-right">
                        <h1>Tecnologia</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor numquam doloremque consectetur repellendus autem. In corporis molestias alias eaque, exercitationem aspernatur, eius tempore, mollitia animi corrupti blanditiis. Eaque, quam facere!</p>
                    </div>
                </div>



                <div class="first-categori second-categori">
                    <div class="content-text category-2 content-left">
                        <h1>Deportes</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores porro dignissimos suscipit facere pariatur distinctio, laudantium nobis ipsum! In assumenda aut adipisci delectus cumque dolore commodi deserunt? Sint, commodi incidunt?</p>
                    </div>
                    <div class="Image-left image-right all-images-cat">
                        <img src="" alt="">
                        <a href="../views/categoria-4/category-4-view.php">
                            <div class="Image-left-overlay Image-left-overlay-blur">
                                <p class="Image-left-description">
                                Deportes
                                </p>
                            </div>
                        </a>
                    </div>
                </div>


                <div class="first-categori second-categori">
                    <div class="Image-left image-right-2 all-images-cat">
                        <img src="" alt="">
                        <a href="../views/categoria-5/category-5-view.php">
                            <div class="Image-left-overlay Image-left-overlay-blur">
                                <p class="Image-left-description">
                                Ropa y calzado
                                </p>
                            </div>
                        </a>
                    </div>
                    <div class="content-text category-2 content-right">
                        <h1>Ropa y calzado</h1>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illo libero laborum veritatis, nisi enim reprehenderit necessitatibus. Praesentium ut dicta omnis temporibus delectus doloremque consectetur nesciunt inventore. Odit eaque corrupti laudantium.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <footer>
            <div class="container-footer">
                <div class="Footer-logo">
                    <img src="../resource/Gonly.png" id="f-logo">
                </div>
                <div class="words">
                    <ul>
                        <li><a href="index-view.php" class="link">Home</a></li>
                        <li><a href="AllCategories-view.php" class="link">Tienda</a></li>
                        <li><a href="terminos-view.php" class="link">Terminos</a></li>
                        <li><a href="../controllers/" >Contacto</a></li>
                    </ul>
                </div>
                <li id="li-translate"><div id="google_translate_element" class="google languaje"></div></li>
                <div class="icons">
                    <ul class="ul-icons-footer">
                    <li><a href="" target="_blank"><div class="icons-footer"> </div></a></li>
                        <li><a href="" target="_blank"><div class="icons-footer ig-icon"> </div> </a></li>
                        <li><a href="" target="_blank"><div class="icons-footer twitter-icon"> </div> </a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </section>
    <script src="../JS/decorationScript-1.js"></script>
    <script type="text/javascript">
      function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'es', includedLanguages: 'ca,eu,gl,en,fr,it,pt,de,es', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true}, 'google_translate_element');
        }
      </script>
      <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</body>
</html>

