

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/404.css">
    <title>Pagina No Encontrada</title>
</head>
<body>
    <img src="../resource/logo7.jpg" alt="">
<section class="error-container">
	<span><span>4</span></span>
	<span>0</span>
	<span><span>4</span></span>
</section>
<section>
<a href="../views/Index-view.php"><button class="btn">¡Regresar!</button></a>
</section>
</body>
</html>